export class Sprite
{
    public id: string;
    public path: string;
    public width: number;
    public height: number;

    public opacity: number;
    public rotation: number;
    public pos: number[];
    public ap: number[];
    public scale: number[];

    public img: HTMLImageElement;
    public loaded: boolean;

    constructor(data: any, idx: number)
    {
        this.id = data.assets[idx].id;
        this.path = data.assets[idx].u + data.assets[idx].p;
        this.width = data.assets[idx].w;
        this.height = data.assets[idx].h;

        this.opacity = data.layers[idx].ks.o.k;
        this.rotation = data.layers[idx].ks.r.k;
        this.pos = data.layers[idx].ks.p.k;
        this.ap = data.layers[idx].ks.a.k;
        this.scale = data.layers[idx].ks.s.k;

        this.img = null;
        this.loaded = false;
    }
}