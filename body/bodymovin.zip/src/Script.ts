import { Sprite } from "./Sprite";

export class Script
{
    protected _httpRequest: XMLHttpRequest;
    protected _ctx: CanvasRenderingContext2D;
    protected _canvas: HTMLCanvasElement;
    protected _jsonImg: Sprite[];
    
    constructor(path: string)
    {
        this._canvas = <HTMLCanvasElement> document.getElementById('canvas');
        this._ctx = this._canvas.getContext('2d');
        this._jsonImg = new Array<Sprite>();
        this.loadJSON(path);
    }

    protected loadJSON(path: string): void
    {
        this._httpRequest = new XMLHttpRequest();
        this._httpRequest.onreadystatechange = () => this.httpRequest();
       
        this._httpRequest.open("GET", path, true);
        this._httpRequest.send();
    }

    protected httpRequest(): void
    {
        if (this._httpRequest.readyState === XMLHttpRequest.DONE) 
        {
            if (this._httpRequest.status === 200)
            {
                this.processData(JSON.parse(this._httpRequest.responseText));
            }
        }
    }

    protected processData(data: any): void
    {
        let idx: number = 0;

        this._canvas.width = data.w;
        this._canvas.height = data.h;

        for(let asset of data.assets)
        {
            this._jsonImg.push(new Sprite(data, idx));
            let img = document.createElement("img");
            this._jsonImg[idx].img = img;

            img.src = asset.u + asset.p;
            img.onload = this.onImgLoad.bind(this, this._jsonImg[idx]);

            idx++;
        }
    }

    protected onImgLoad(sprite: Sprite): void
    {
        /* Render every image on every new image load */
        sprite.loaded = true;
        this.render();
    }

    protected render(): void
    {
        this._ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);     // Clearing the canvas

        for (let idx: number = this._jsonImg.length - 1; idx >= 0; idx--)       // Drawing the images in reverse order
        {
            let sprite = this._jsonImg[idx];

            if (sprite.loaded)
            {
                this.drawImage(sprite);
            }
        }
    }

    protected drawImage(sprite: Sprite): void
    {   
        this._ctx.save();                                                   // Save the default state of the canvas

        this._ctx.translate(sprite.pos[0], sprite .pos[1]);                 // Positioning the canvas before setting up the draw parameters

        this.setDrawParams(sprite);                                         // Setting up the draw parameters

        this._ctx.drawImage(sprite.img, -sprite.ap[0], -sprite.ap[1]);      // Drawing the image on the canvas according to the anchor point

        this._ctx.restore();                                                // Restore canvas to its starting state
    }

    protected setDrawParams(sprite: Sprite): void
    {
        /* Opacity */
        if (sprite.opacity != 100)
        {
            this._ctx.globalAlpha = sprite.opacity / 100;
        }
         
        /* Scale  */
        if (sprite.scale[0] != 100 || sprite.scale[1] != 100)
        {
            this._ctx.scale(sprite.scale[0] / 100, sprite.scale[1] / 100);
        }

        /* Rotate */
        if (sprite.rotation != 0)                
        {
            this._ctx.rotate(sprite.rotation * Math.PI / 180);
        }
    }
}